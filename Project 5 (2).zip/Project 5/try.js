//$(document).ready(function() {

  var cardsInDeck = new Array();
  var numberOfCardsInDeck = 52;
  var cardsInHand = 0;
  var currentHand = new Array();
  var j  = 0;
  /*var cardCount; 
  for(cardCount = 0; cardCount < 52; cardCount++)
  {
    cardsInDeck[cardCount]
  }*/
  // create cards indicidually
  cardsInDeck[0] = "AceOfHearts";
  cardsInDeck[1] = "2OfHearts";
  cardsInDeck[2] = "3OfHearts";
  cardsInDeck[3] = "4OfHearts";
  cardsInDeck[4] = "5OfHearts";
  cardsInDeck[5] = "6OfHearts";
  cardsInDeck[6] = "7OfHearts";
  cardsInDeck[7] = "8OfHearts";
  cardsInDeck[8] = "9OfHearts";
  cardsInDeck[9] = "10OfHearts";
  cardsInDeck[10] = "JackOfHearts";
  cardsInDeck[11] = "QueenOfHearts";
  cardsInDeck[12] = "KingOfHearts";

  cardsInDeck[13] = "AceOfDiamonds";
  cardsInDeck[14] = "2OfDiamonds";
  cardsInDeck[15] = "3OfDiamonds";
  cardsInDeck[16] = "4OfDiamonds";
  cardsInDeck[17] = "5OfDiamonds";
  cardsInDeck[18] = "6OfDiamonds";
  cardsInDeck[19] = "7OfDiamonds";
  cardsInDeck[20] = "8OfDiamonds";
  cardsInDeck[21] = "9OfDiamonds";
  cardsInDeck[22] = "10OfDiamonds";
  cardsInDeck[23] = "JackOfDiamonds";
  cardsInDeck[24] = "QueenOfDiamonds";
  cardsInDeck[25] = "KingOfDiamonds";

  cardsInDeck[26] = "AceOfClubs";
  cardsInDeck[27] = "2OfClubs";
  cardsInDeck[28] = "3OfClubs";
  cardsInDeck[29] = "4OfClubs";
  cardsInDeck[30] = "5OfClubs";
  cardsInDeck[31] = "6OfClubs";
  cardsInDeck[32] = "7OfClubs";
  cardsInDeck[33] = "8OfClubs";
  cardsInDeck[34] = "9OfClubs";
  cardsInDeck[35] = "10OfClubs";
  cardsInDeck[36] = "JackOfClubs";
  cardsInDeck[37] = "QueenOfClubs";
  cardsInDeck[38] = "KingOfClubs";
  
  cardsInDeck[39] = "AceOfSpades";
  cardsInDeck[40] = "2OfSpades";
  cardsInDeck[41] = "3OfSpades";
  cardsInDeck[42] = "4OfSpades";
  cardsInDeck[43] = "5OfSpades";
  cardsInDeck[44] = "6OfSpades";
  cardsInDeck[45] = "7OfSpades";
  cardsInDeck[46] = "8OfSpades";
  cardsInDeck[47] = "9OfSpades";
  cardsInDeck[48] = "10OfSpades";
  cardsInDeck[49] = "JackOfSpades";
  cardsInDeck[50] = "QueenOfSpades";
  cardsInDeck[51] = "KingOfSpades";

$(document).ready(function() {

$("#deal").click(function () 
{
  //var msg = 'nocards';
 // console.log(msg);
  dealCard(randomCard());
  console.log(numberOfCardsInDeck);
});

$("#discard").click(function()
{
  discardCard();
	console.log('This button worked for discard');
});

$("#fold").click(function()
{
	console.log('This button worked for fold');
});


function dealCard(i)
{
  var msg = 'nocards';
	if((numberOfCardsInDeck == 0) || (cardsInHand == 5))
  {
    console.log(msg);
  	return false;
  }
  var image = document.createElement("img");
  image.src = cardsInDeck[i]+".png";
  currentHand[j] = i;
  j++;
  document.body.appendChild(image);
  //document.body.removeChild(image);
  removeCard(i);
  cardsInHand++;
}

function randomCard() 
{
	return Math.floor(Math.random() * numberOfCardsInDeck);
}

function removeCard(c)
{
	for(j=c; j <= numberOfCardsInDeck - 2; j++)
  {
  	cardsInDeck[j] = cardsInDeck[j+1];
  }
  numberOfCardsInDeck--;
}

function compareHand()
{

}

function discardCard()
{
  var testImage = document.createElement("img");
  testImage.src = currentHand[j-1]+".png";
  j--;
  document.body.removeChild(testImage);
  cardsInHand--;
}

});