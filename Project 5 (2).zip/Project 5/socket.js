let app = require('http').createServer(); // create HTTP server
let io = require('socket.io')(app, {path: '/socket.io'}); // bind Socket to HTTP server
app.listen(3000); // listen on port 3000
var nums = 0;
console.log(nums);
console.log('Listening for connections on port 3000');
//while(nums < 4)
//{
	io.on('connection', function(socket) 
	{
   		console.log('Socket connected');
   		socket.join('my-room'); // join the socket into the room called 'my-room'
   		var room = io.sockets.adapter.rooms['my-room'];
   		nums = room.length;
		  console.log(room.length);
   		socket.in('my-room').emit('fromServer', {id: 'foo'}); // send to all clients in room
   		socket.on('fromClient', function(data) 
   		{ // listen for fromClient message
      		console.log('Received ' + data.id + ' from client'); // single client
   		});
      socket.on('testone', function(data)
      {
        console.log('Just testing to see')
      });
	});
//}
